/*
 * Copyright (c) 2020. Adam Arthur Faizal.
 */

define( [
	"../../core",
	"../../selector"
], function( jQuery ) {
	"use strict";

	return jQuery.expr.match.needsContext;
} );
