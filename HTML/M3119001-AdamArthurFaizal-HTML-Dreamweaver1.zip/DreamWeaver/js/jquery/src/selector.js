/*
 * Copyright (c) 2020. Adam Arthur Faizal.
 */

define( [ "./selector-sizzle" ], function() {
	"use strict";
} );
