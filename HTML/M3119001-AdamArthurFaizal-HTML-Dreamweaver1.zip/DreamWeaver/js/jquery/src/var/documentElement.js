/*
 * Copyright (c) 2020. Adam Arthur Faizal.
 */

define( [
	"./document"
], function( document ) {
	"use strict";

	return document.documentElement;
} );
