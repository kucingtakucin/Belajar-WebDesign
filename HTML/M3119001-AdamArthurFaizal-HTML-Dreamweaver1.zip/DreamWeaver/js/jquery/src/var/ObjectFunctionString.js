/*
 * Copyright (c) 2020. Adam Arthur Faizal.
 */

define( [
	"./fnToString"
], function( fnToString ) {
	"use strict";

	return fnToString.call( Object );
} );
