/*
 * Copyright (c) 2020. Adam Arthur Faizal.
 */

define( [
	"./hasOwn"
], function( hasOwn ) {
	"use strict";

	return hasOwn.toString;
} );
