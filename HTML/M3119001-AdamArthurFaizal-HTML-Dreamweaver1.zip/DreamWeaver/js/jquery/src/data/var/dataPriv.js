/*
 * Copyright (c) 2020. Adam Arthur Faizal.
 */

define( [
	"../Data"
], function( Data ) {
	"use strict";

	return new Data();
} );
