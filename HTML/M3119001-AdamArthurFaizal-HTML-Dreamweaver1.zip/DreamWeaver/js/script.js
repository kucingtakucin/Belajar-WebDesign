/*
 * Copyright (c) 2020. Adam Arthur Faizal.
 */

$(document).ready(function () {
    $('.navbar-toggler').click(function () {
        $('.collapse').collapse('toggle');
    });
});