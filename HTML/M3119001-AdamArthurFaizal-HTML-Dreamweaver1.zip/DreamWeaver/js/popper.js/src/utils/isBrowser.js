/*
 * Copyright (c) 2020. Adam Arthur Faizal.
 */

export default typeof window !== 'undefined' && typeof document !== 'undefined' && typeof navigator !== 'undefined';
